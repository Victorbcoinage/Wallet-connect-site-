﻿namespace WalletConnectSharp.Core
{
    [Obsolete("WalletConnectSharp is now considered deprecated and will reach End-of-Life on February 17th 2025. For more details, including migration guides please see: https://docs.reown.com")]
    public class Core : WalletConnectCore {  }
}
