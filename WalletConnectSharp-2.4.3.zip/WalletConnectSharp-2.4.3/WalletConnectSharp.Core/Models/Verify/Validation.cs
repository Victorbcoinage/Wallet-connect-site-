﻿namespace WalletConnectSharp.Core.Models.Verify;

public enum Validation
{
    Unknown,
    Valid,
    Invalid,
}
