namespace WalletConnectSharp.Core.Models.Relay
{
    /// <summary>
    /// Options for subscribing to a topic
    /// </summary>
    public class SubscribeOptions : ProtocolOptionHolder
    {
    }
}
