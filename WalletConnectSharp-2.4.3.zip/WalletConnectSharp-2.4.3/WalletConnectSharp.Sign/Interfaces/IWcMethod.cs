using System;

namespace WalletConnectSharp.Sign.Interfaces
{
    /// <summary>
    /// An interface that is used to represent specific
    /// WalletConnect requests.
    /// </summary>
    public interface IWcMethod
    {
        
    }
}
