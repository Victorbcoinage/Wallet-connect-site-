﻿namespace WalletConnectSharp.Sign.Models;

public struct Caip25Address
{
    public string Address;
    public string ChainId;
}
